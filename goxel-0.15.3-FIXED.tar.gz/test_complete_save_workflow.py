#!/usr/bin/env python3

import socket
import json
import subprocess
import time
import os

def test_complete_save_workflow():
    """Test the complete workflow including save_project"""
    
    daemon_socket = "/tmp/goxel_save_test.sock"
    
    # Remove existing socket
    if os.path.exists(daemon_socket):
        os.unlink(daemon_socket)
    
    # Start the daemon in background
    print("🧪 Testing complete save workflow...")
    daemon_proc = subprocess.Popen([
        "./goxel-daemon", 
        "--foreground", 
        "--socket", 
        daemon_socket
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for daemon to start
    max_retries = 10
    for i in range(max_retries):
        if os.path.exists(daemon_socket):
            break
        time.sleep(0.5)
    else:
        print("❌ Daemon failed to start")
        daemon_proc.kill()
        return False
    
    print("✅ Daemon started")
    
    try:
        # Connect to daemon
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(10)  # Reasonable timeout
        sock.connect(daemon_socket)
        
        print("✅ Connected to daemon")
        
        # Test complete workflow
        requests = [
            {
                "jsonrpc": "2.0",
                "method": "goxel.create_project",
                "params": ["SaveTestProject", 32, 32, 32],
                "id": 1
            },
            {
                "jsonrpc": "2.0", 
                "method": "goxel.add_voxel",
                "params": [16, 16, 16, 255, 0, 0, 255],
                "id": 2
            },
            {
                "jsonrpc": "2.0",
                "method": "goxel.save_project", 
                "params": [os.path.join(os.getcwd(), "fixed_daemon_test.gox")],
                "id": 3
            }
        ]
        
        for i, request in enumerate(requests):
            method_name = request['method']
            print(f"📤 Request {i+1}: {method_name}")
            start_time = time.time()
            
            # Send request
            message = json.dumps(request) + "\n"
            sock.send(message.encode())
            
            # Receive response 
            response_data = sock.recv(4096).decode().strip()
            response = json.loads(response_data)
            
            elapsed = time.time() - start_time
            print(f"📥 Response {i+1} (took {elapsed:.2f}s): {response}")
            
            # Check for errors
            if "error" in response:
                print(f"❌ Error in {method_name}: {response['error']}")
                return False
            
            # Special validation for save_project
            if method_name == "goxel.save_project":
                if response.get("result", {}).get("success"):
                    print("🎉 SAVE_PROJECT FIX CONFIRMED!")
                    # Check if file was created
                    save_path = os.path.join(os.getcwd(), "fixed_daemon_test.gox")
                    if os.path.exists(save_path):
                        file_size = os.path.getsize(save_path)
                        print(f"✅ File saved: {save_path} ({file_size} bytes)")
                        os.unlink(save_path)  # Clean up
                    else:
                        print("⚠️  File not found, but no error returned")
                else:
                    print("❌ save_project did not return success")
                    return False
                    
        sock.close()
        print("🎊 ALL TESTS PASSED! Save workflow is fully functional!")
        return True
            
    except socket.timeout:
        print("❌ Request timed out")
        return False
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        return False
    finally:
        # Cleanup
        try:
            sock.close()
        except:
            pass
        try:
            daemon_proc.terminate()
            daemon_proc.wait(timeout=5)
        except:
            daemon_proc.kill()
        if os.path.exists(daemon_socket):
            os.unlink(daemon_socket)

if __name__ == "__main__":
    success = test_complete_save_workflow()
    if success:
        print("✅ SAVE WORKFLOW VALIDATION PASSED!")
        exit(0)
    else:
        print("❌ SAVE WORKFLOW VALIDATION FAILED!")
        exit(1)